"""
本地预览用的小脚本（不影响你部署到网上）。

用法：
  python3 game.py
然后浏览器打开：
  http://127.0.0.1:8000/
"""

from __future__ import annotations

from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler


def main() -> None:
    host = "127.0.0.1"
    port = 8000
    print("🎄 正在启动本地预览服务…")
    print(f"打开：http://{host}:{port}/")
    print("停止：按 Ctrl+C")
    ThreadingHTTPServer((host, port), SimpleHTTPRequestHandler).serve_forever()


if __name__ == "__main__":
    main()



